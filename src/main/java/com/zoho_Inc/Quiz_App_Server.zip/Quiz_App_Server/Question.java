package com.zoho_Inc.Quiz_App_Server;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

class Question {
    private int id;
    private String questionText;
    private int categoryId;
    private int answerId;
//    private static final long serialVersionUID = 2L;
    
    @JsonCreator
    public Question(
            @JsonProperty("id") int id,
            @JsonProperty("questionText") String questionText,
            @JsonProperty("categoryId") int categoryId,
            @JsonProperty("answerId") int answerId) {
        this.id = id;
        this.questionText = questionText;
        this.categoryId = categoryId;
        this.answerId = answerId;
    }
//    public Question(int id, String questionText, int categoryId, int answerId) {
//        this.id = id;
//        this.questionText = questionText;
//        this.categoryId = categoryId;
//        this.answerId = answerId;
//    }

	public void setId(int id) {
		this.id = id;
	}
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}
	public int getId() {
        return id;
    }

    public String getQuestionText() {
        return questionText;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public int getAnswerId() {
        return answerId;
    }

//    public String toString() {
//        return "id: " + id + "\nquestionText: " + questionText + "\ncategory: " + categoryId + "\nanswerId: " + answerId;
//    }
    @Override
    public String toString() {
        return "id: " + id + "\nquestionText: " + questionText + "\ncategory: " + categoryId + "\nanswerId: " + answerId;
    }
}