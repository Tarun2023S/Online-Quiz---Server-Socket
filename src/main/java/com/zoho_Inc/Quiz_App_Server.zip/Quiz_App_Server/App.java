package com.zoho_Inc.Quiz_App_Server;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Hello world!
 *
 */
public class App 
{
	private static String url = "jdbc:mysql://localhost:3306/";
    private static String userName = "root";
    private static String password = "root";
    
	public static void main(String[] args) {
		try {
//			Socket socket = null;
//			InputStreamReader inputStreamReader = null;
//			OutputStreamWriter outputStreamWriter = null;
//			BufferedReader bufferedReader = null;
//			BufferedWriter bufferedWriter = null;
			ServerSocket serverSocket = null;
			int portNumber = 1230;
			Connection connection = DriverManager.getConnection(url, userName, password);
			serverSocket = new ServerSocket(portNumber);
//			while(true) {
//				System.out.println("Waiting for connection");
//				socket = serverSocket.accept();
//				System.out.println("Server Started..");
//				inputStreamReader = new InputStreamReader(socket.getInputStream());
//				outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());
//				
//				bufferedReader = new BufferedReader(inputStreamReader);
//				bufferedWriter = new BufferedWriter(outputStreamWriter);
//				while(true) {
//					String msgFromClient = bufferedReader.readLine();
//					System.out.println("Msg from Client: "+msgFromClient);
//					
//					bufferedWriter.write("Msg Received..");
//					bufferedWriter.newLine();
//					bufferedWriter.flush();
//					
//					if(msgFromClient.equalsIgnoreCase("BYE")) {
//						break;
//					}
//				}
//								
////				closeAllResources1();
//				try {
//					if(socket != null) {
//						socket.close();
//					}
//					if(inputStreamReader != null) {
//						inputStreamReader.close();
//					}
//					if(outputStreamWriter != null) {
//						outputStreamWriter.close();
//					}
//					if(bufferedReader != null) {
//						bufferedReader.close();
//					}
//					if(bufferedWriter != null) {
//						bufferedWriter.close();
//					}
//				}
//				catch(Exception e) {
//					e.printStackTrace();
//				}
//			}
//			try {
//	            Class.forName("com.mysql.cj.jdbc.Driver");
//	        } catch (ClassNotFoundException e) {
//	            e.printStackTrace();
//	            return;
//	        }
			while (true) {
				System.out.println("Waiting for connection");
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected");
                
//                inputStreamReader = new InputStreamReader(clientSocket.getInputStream());
//				outputStreamWriter = new OutputStreamWriter(clientSocket.getOutputStream());
//				
//				bufferedReader = new BufferedReader(inputStreamReader);
//				bufferedWriter = new BufferedWriter(outputStreamWriter);
   
                if (!DBManager.databaseExists(connection)) {
                    DBManager.createDatabase(connection);
                }

                DBManager.createNecessaryTables(connection);
                ClientManager dbm = new ClientManager(connection);
//                 Handle the client connection in a new thread
//                new Thread(() -> ClientManager.handleClient(clientSocket)).start();
             // Handle the client connection in a new thread
//                new Thread(() -> {
//                    try {
//                        ClientManager.handleClient(clientSocket);
//                    } finally {
//                        // Close resources related to this client
//                        try {
//                            clientSocket.close();
//                        } catch (IOException ioException) {
//                            ioException.printStackTrace();
//                        }
//                    }
//                }).start();
                ClientManager.handleClient(clientSocket);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("Close: ");
		}

	}
}
