package com.zoho_Inc.Quiz_App_Server;

import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//import com.zoho_Inc.QuizApp.DBManager;

import java.sql.*;
import java.net.*;

public class ClientManager implements Runnable {
	
	public static ArrayList<ClientManager> clientHandlers = new ArrayList();
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	
	private static Connection connection;
	private String playerName;
	public ClientManager() {
		
	}
	public ClientManager(Socket socket, Connection connection) {
		this.connection = connection;
		try {
			this.socket = socket;
			this.oos = new ObjectOutputStream(socket.getOutputStream());
			this.ois = new ObjectInputStream(socket.getInputStream());
			this.playerName = (String) ois.readObject();
			clientHandlers.add(this);
			System.out.println("S: CH'sz: "+clientHandlers.size());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) { 
			e.printStackTrace();
		} finally {
			System.out.println("S: Finally of CM Const");
		}
		
	}
    public ClientManager(Connection connection, String playerName) {
        this.connection = connection;
        this.playerName = playerName;
    }

	 void handleClient(Socket clientSocket) {
	        try {
	        	
	            int clientChoice = ois.readInt();
	            // Process the client's choice on the server side
	            processClientChoice(clientChoice, oos, ois, clientSocket);
//	            System.out.println("Classpath: " + System.getProperty("java.class.path"));

	        } catch (EOFException e) {
	            // Client disconnected
	        	clientHandlers.remove(this);
	            System.out.println("Client disconnected.");
	            closeConnection(clientSocket);
	            return;
	            // Additional handling if needed, such as cleaning up resources or logging
	        } catch (IOException e) {
	            // Handle other exceptions
	            e.printStackTrace();
	        } 
	    }

	    private void processClientChoice(int clientChoice, ObjectOutputStream oos, ObjectInputStream ois, Socket clientSocket) {
	        // Implement the logic to process the client's choice on the server side
	    	System.out.println("S: Recieved choice from client: "+clientChoice);
//	    	Person p = new Person("Batista");
	        switch (clientChoice) {
	            case 1:
	                // Handle playGame on the server
	            	GameManager.playGame(connection, -1, oos, ois, clientSocket);

	                break;
	            case 2:
	                // Handle fetchQuestionsCategoryWise on the server
	            	GameManager.playGame(connection, -1, oos, ois, clientSocket);
	                break;
	            case 3:
	                // Handle displayAllQuestions on the server
//	            	displayAllQns(oos, clientSocket);
	                break;
	            case 4:
	            	// Handle displayAllQuestions on the server
	            	displayAllQns(oos, clientSocket);
	                break;
	            case 6:
	                System.out.println("Client requested to exit. Closing connection.");
	                closeConnection(clientSocket);
	                break;

	            default:
	                System.out.println("Invalid client choice received.");
	        }
	    }
	    
	    public void closeConnection(Socket clientSocket) {
	        try {
	            if (clientSocket != null && !clientSocket.isClosed()) {
	                clientSocket.close();
	                clientHandlers.remove(this);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    
	    public static void displayAllQns(ObjectOutputStream oos, Socket clientSocket) {
	    	List<com.zoho_Inc.Quiz_App_Server.GameManager.Question> questions = null;
	    	questions = DBManager.fetchDataFromTheTables("question", connection);
        	ObjectMapper objectMapper = new ObjectMapper();
        	String json;
			try {
				json = objectMapper.writeValueAsString(questions);
	        	 // Check if the connection is still open before writing to the output stream
	            if (!clientSocket.isClosed()) {
	                oos.writeObject(json);
	                oos.flush();
	            }
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch(IOException e) {
				System.out.println("S: error occurred: "+e.getMessage());
			}
	    }
	    
	    public static int validChoiceForInteger() {
	        int choice = -1;
	        boolean validInput = false;
	        Scanner sc = new Scanner(System.in);

	        while (!validInput) {
	            try {
	                System.out.print("Enter a valid integer: ");
	                choice = Integer.parseInt(sc.nextLine());
	                validInput = true; // If parsing succeeds, mark the input as valid
	            } catch (NumberFormatException e) {
	                System.out.println("Invalid input. Please enter a valid integer.");
	            }
	        }

	        return choice;
	    }
		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("Connected");

	        try {
	            while (true) {
	                int clientChoice = ois.readInt();
	                if (clientChoice == -1) {
	                    // Client sent a disconnection signal
	                	closeConnection(socket);
	                    System.out.println("Client disconnected.");
	                    break;
	                }

	                processClientChoice(clientChoice, oos, ois, socket);
	            }
	        } catch(SocketException e) {
	        	System.out.println("S: Socket exception");
	        } catch (IOException e) {
	            // Handle IOException (client disconnected or other errors)
	            e.printStackTrace();
	        } finally {
	            // Close resources and cleanup
	            closeConnection(socket);
	        }
		}

}
