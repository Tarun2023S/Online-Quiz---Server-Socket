package com.zoho_Inc.Quiz_App_Server;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Hello world!
 *
 */
public class Server 
{
	private static String url = "jdbc:mysql://localhost:3306/";
    private static String userName = "root";
    private static String password = "root";
    
	public static void main(String[] args) {
		try {
			ServerSocket serverSocket = null;
			int portNumber = 1230;
			Connection connection = DriverManager.getConnection(url, userName, password);
			serverSocket = new ServerSocket(portNumber);

			while (true) {
				System.out.println("Waiting for connection");
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected");
                
                if (!DBManager.databaseExists(connection)) {
                    DBManager.createDatabase(connection);
                }

                DBManager.createNecessaryTables(connection);
                ClientManager dbm = new ClientManager(connection, "");
                
             // Handle the client connection in a new thread
                new Thread(() -> {
                    try {
                        ClientManager.handleClient(clientSocket);
                    } finally {
                        // Close resources related to this client
                        try {
                            clientSocket.close();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    }
                }).start();
//                ClientManager.handleClient(clientSocket);
			}
			
		}  catch (SocketException e) {
            // Handle the SocketException (Connection reset) gracefully
            System.out.println("Client disconnected unexpectedly.");
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("Close: ");
		}

	}
}
