package com.zoho_Inc.Quiz_App_Server;

import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//import com.zoho_Inc.QuizApp.DBManager;

import java.sql.*;
import java.net.*;

public class ClientManager {
	
	private static Connection connection;
	private static String playerName;
	public ClientManager() {
		
	}
    public ClientManager(Connection connection, String playerName) {
        this.connection = connection;
        this.playerName = playerName;
    }

    public static List<String> playerList = new ArrayList();
//    public void start() {
//        try (ServerSocket serverSocket = new ServerSocket(9090)) {
//            System.out.println("Server started. Waiting for clients...");
//
//            while (true) {
//                Socket clientSocket = serverSocket.accept();
//                System.out.println("Client connected");
//
//                // Handle the client connection in a new thread
//                new Thread(() -> handleClient(clientSocket)).start();
//                System.out.println("CLient disconnected..");
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
     boolean firstTimeLogin = false;
	 void handleClient(Socket clientSocket) {
	        try (ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
	             ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream())) {
	        	
//	        	if(!firstTimeLogin) {
//	        		String plName = (String) ois.readObject();
//	        		playerList.add(plName);
//	        		firstTimeLogin = true;
//	        	}
	        	
	        	System.out.println("S: PLSize: "+playerList.size());
	            int clientChoice = ois.readInt();
//	            System.out.println("S: Received choice from client: " + clientChoice);

	            // Process the client's choice on the server side
	            processClientChoice(clientChoice, oos, ois, clientSocket);

//	            System.out.println("Classpath: " + System.getProperty("java.class.path"));

	        } catch (IOException e) {
	            e.printStackTrace();
	        } 
	    }

	    private static void processClientChoice(int clientChoice, ObjectOutputStream oos, ObjectInputStream ois, Socket clientSocket) {
	        // Implement the logic to process the client's choice on the server side
	    	System.out.println("S: Recieved choice from client: "+clientChoice);
//	    	Person p = new Person("Batista");
	        switch (clientChoice) {
	            case 1:
	                // Handle playGame on the server
	            	GameManager.playGame(connection, -1, oos, ois, clientSocket);

	                break;
	            case 2:
	                // Handle fetchQuestionsCategoryWise on the server
	            	GameManager.playGame(connection, -1, oos, ois, clientSocket);
	                break;
	            case 3:
	                // Handle displayAllQuestions on the server
//	            	DBManager.displayAllQuestions(connection);
	            	displayAllQns(oos, clientSocket);
	                break;
	            case 4:
	                // Handle displayOptionsForQuestion on the server
//	            	System.out.print("Enter question_id to display options: ");
//					int questionId;
//					try {
//						questionId = ois.readInt();
//						sendOptionsForQuestion(oos, connection, questionId, clientSocket);
//					} catch (IOException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
	                break;
	            case 6:
	                System.out.println("Client requested to exit. Closing connection.");
	                closeConnection(clientSocket);
	                break;

	            default:
	                System.out.println("Invalid client choice received.");
	        }
	    }
	    
	    public static void closeConnection(Socket clientSocket) {
	        try {
	            clientSocket.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    
	    public static void displayAllQns(ObjectOutputStream oos, Socket clientSocket) {
	    	List<Question> questions = null;
	    	questions = DBManager.fetchDataFromTheTables("question", connection);
        	ObjectMapper objectMapper = new ObjectMapper();
        	String json;
			try {
				json = objectMapper.writeValueAsString(questions);
				oos.writeObject(json);
	        	 // Check if the connection is still open before writing to the output stream
	            if (!clientSocket.isClosed()) {
	                oos.writeObject(json);
	                oos.flush();
	            }
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch(IOException e) {
				System.out.println("S: error occurred: "+e.getMessage());
			}
	    }
	    
	    public static int validChoiceForInteger() {
	        int choice = -1;
	        boolean validInput = false;
	        Scanner sc = new Scanner(System.in);

	        while (!validInput) {
	            try {
	                System.out.print("Enter a valid integer: ");
	                choice = Integer.parseInt(sc.nextLine());
	                validInput = true; // If parsing succeeds, mark the input as valid
	            } catch (NumberFormatException e) {
	                System.out.println("Invalid input. Please enter a valid integer.");
	            }
	        }

	        return choice;
	    }

}
